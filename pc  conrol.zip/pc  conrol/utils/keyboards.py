def main_keyboard():

    from vk_api.keyboard import VkKeyboard, VkKeyboardColor
    from utils.config import settings

    keyboard = VkKeyboard(one_time=False)
    keyboard.add_button(f'{settings["prefix"]}check', color=VkKeyboardColor.PRIMARY)
    keyboard.add_button(f'{settings["prefix"]}blue', color=VkKeyboardColor.PRIMARY)
    keyboard.add_line()
    keyboard.add_button(f'{settings["prefix"]}process', color=VkKeyboardColor.PRIMARY)
    keyboard.add_button(f'{settings["prefix"]}screen', color=VkKeyboardColor.PRIMARY)
    keyboard.add_line()
    keyboard.add_button(f'{settings["prefix"]}info_pc', color=VkKeyboardColor.PRIMARY)
    keyboard.add_button(f'{settings["prefix"]}micro', color=VkKeyboardColor.PRIMARY)
    keyboard.add_line()
    keyboard.add_button(f'➡', color=VkKeyboardColor.PRIMARY)

    get_keyboard = keyboard.get_keyboard()

    return get_keyboard


def second_main_keyboard():
    from vk_api.keyboard import VkKeyboard, VkKeyboardColor
    from utils.config import settings

    keyboard = VkKeyboard(one_time=False)
    keyboard.add_button(f'{settings["prefix"]}minimize', color=VkKeyboardColor.PRIMARY)
    keyboard.add_button(f'{settings["prefix"]}off', color=VkKeyboardColor.PRIMARY)
    keyboard.add_line()
    keyboard.add_button(f'{settings["prefix"]}photo', color=VkKeyboardColor.PRIMARY)
    keyboard.add_button(f'{settings["prefix"]}restart', color=VkKeyboardColor.PRIMARY)
    keyboard.add_line()
    keyboard.add_button(f'{settings["prefix"]}sleep', color=VkKeyboardColor.PRIMARY)
    keyboard.add_button(f'{settings["prefix"]}block', color=VkKeyboardColor.PRIMARY)
    keyboard.add_line()
    keyboard.add_button(f'⬅', color=VkKeyboardColor.PRIMARY)

    get_keyboard = keyboard.get_keyboard()

    return get_keyboard




