settings = {
    'api_heather': 'TOKEN',
    'api_group_vk': 'TOKEN',
    'vk_str_token': 'TOKEN',
    'prefix': '/',
    'group_id': 1234567,
    'owner_id': 123456,

}
