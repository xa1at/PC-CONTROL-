def function_sleep_mode():
    import os

    os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
