def function_block_screen():
    import os

    os.system('Rundll32.exe user32.dll,LockWorkStation')
