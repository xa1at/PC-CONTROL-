def get_process():
    import psutil

    processes = []
    for proc in psutil.process_iter():
        try:
            process_name = proc.name()
            processes.append(process_name)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    processes = ', '.join(map(str, processes))
    return processes
