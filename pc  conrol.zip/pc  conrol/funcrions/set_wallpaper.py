def main_wallpaper_function(event):
    import ctypes
    import os
    import requests

    def set_wallpaper(file_path):

        file_path = os.path.abspath(file_path)

        spi = 20
        ctypes.windll.user32.SystemParametersInfoW(spi, 0, file_path, 0)

    def handle_message(event):
        message = event.obj.message
        user_id = message['from_id']
        attachments = message.get('attachments')

        if attachments:
            for attachment in attachments:
                if attachment['type'] == 'photo':
                    photo_url = attachment['photo']['sizes'][-1]['url']

                    photo_data = requests.get(photo_url).content
                    with open('wallpaper.jpg', 'wb') as f:
                        f.write(photo_data)

                    set_wallpaper('wallpaper.jpg')

                    break
    handle_message(event=event)
