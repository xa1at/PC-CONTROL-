def function_for_minimize_all_windows():

    import os

    os.system('powershell -Command "(New-Object -ComObject Shell.Application).MinimizeAll()"')
