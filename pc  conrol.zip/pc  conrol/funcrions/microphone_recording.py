def main_record_audio(users_id):
    import vk_api

    from utils.config import settings
    from vk_api.utils import get_random_id

    vk_session = vk_api.VkApi(token=settings['vk_str_token'])
    vk = vk_session.get_api()

    def record_audio():
        import pyaudio
        import wave

        audio = pyaudio.PyAudio()
        stream = audio.open(format=pyaudio.paInt16, channels=1, rate=44100, input=True, frames_per_buffer=1024)

        frames = []
        for i in range(0, int(44100 / 1024 * 15)):
            data = stream.read(1024)
            frames.append(data)
        wave_file = wave.open("audio.wav", 'wb')
        wave_file.setnchannels(1)
        wave_file.setsampwidth(audio.get_sample_size(pyaudio.paInt16))
        wave_file.setframerate(44100)
        wave_file.writeframes(b''.join(frames))
        wave_file.close()

    def upload_audio_file():
        import requests
        import json

        upload_url = vk.docs.getUploadServer(type='audio_message')['upload_url']
        files = {'file': open('audio.wav', 'rb')}
        response = requests.post(upload_url, files=files)
        file_data = json.loads(response.text)['file']

        return vk.docs.save(file=file_data, title='audio_message')

    def send_audios():
        record_audio()
        audio_file = upload_audio_file()
        vk.messages.send(user_id=users_id, message='Запись микро: ',
                         random_id=get_random_id(),
                         attachment=f"doc{audio_file['audio_message']['owner_id']}_"
                                    f"{audio_file['audio_message']['id']}")

    send_audios()
