def upload_audio_file():
    import vk_api
    from utils.config import settings
    import requests
    import json

    vk_session = vk_api.VkApi(token=settings['api_group_vk'])
    vk = vk_session.get_api()

    upload_url = vk.docs.getUploadServer(type='audio_message')['upload_url']
    files = {'file': open('audio.wav', 'rb')}
    response = requests.post(upload_url, files=files)
    file_data = json.loads(response.text)['file']

    return vk.docs.save(file=file_data, title='audio_message')[0]
