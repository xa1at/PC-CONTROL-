def function_open_url(text):
    import webbrowser

    urls = text[4::]
    webbrowser.open(urls)
