def function_restart_pc():

    import os

    os.system('shutdown /r /t 0')
