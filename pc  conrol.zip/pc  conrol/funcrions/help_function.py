def help_commands_function():

    from utils.config import settings

    prefix = settings['prefix']
    return f'⚡ Доступные команды: ⚡\n\n' \
           f'⭐ {prefix}check - Проверка работоспособности скрипта.\n' \
           f'⭐ {prefix}block - Блокировка экрана.\n' \
           f'⭐ {prefix}blue - Синий экран "смерти". Сразу предупреждаю, введя команду, вы вводить ее по своей' \
           f' инициативе, я не виноват). Ничего страшного конечно не случится,' \
           f' но ПК возможно надо будет перезагрузить.\n' \
           f'⭐ {prefix}process - Функция получения текущих процессов.\n' \
           f'⭐ {prefix}screen - Скриншот экрана.\n' \
           f'⭐ {prefix}heather [CITY] - Погода, CITY обязательный параметр.\n' \
           f'⭐ {prefix}info_pc - Информация о вашем ПК.\n' \
           f'⭐ {prefix}micro - Запись микрофона (15 секунд).\n' \
           f'⭐ {prefix}minimize - Свернуть все окна.\n' \
           f'⭐ {prefix}off - Отключение ПК.\n' \
           f'⭐ {prefix}open [URL] - Открытие ссылки, URL обязательный параметр.\n' \
           f'⭐ {prefix}photo - Фото с вебкамеры.\n' \
           f'⭐ {prefix}restart - Перезагрузка ПК.\n' \
           f'⭐ {prefix}set [КАРТИНКА]- Сменить обои, фото прикреплять к сообщению.\n' \
           f'⭐ {prefix}sleep - Уход в спящий режим.\n' \
           f'⭐ {prefix}start [PROGRAM] - Запуск программы, PROGRAM обязательный параметр.'
