def heather_check(city):
    import requests
    from utils.config import settings

    api_key = settings['api_heather']
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        temperature = data['main']['temp'] - 273.15
        feels_like = data['main']['feels_like'] - 273.15
        humidity = data['main']['humidity']
        wind_speed = data['wind']['speed']
        return f"Температура: {temperature:.1f}°C\n" \
               f"Ощущается как: {feels_like:.1f}°C\n" \
               f"Влажность: {humidity}%\n" \
               f"Скорость ветра: {wind_speed} м/с"
    else:
        return "Не удалось получить погоду. Проверьте правильность написания города."
