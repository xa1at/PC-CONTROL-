def function_start_program(program_name):
    import subprocess

    subprocess.run(program_name, shell=True)
