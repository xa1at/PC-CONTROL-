def pc_information():
    import platform
    import psutil

    info = 'PC INFORMATION\n'
    info += f'Процессор: {platform.processor()}\n'
    info += f'ОЗУ {round(psutil.virtual_memory().total / (1024.0 ** 3))} GB\n'
    info += f'Дисковое пространство: {round(psutil.disk_usage("/").total / (1024.0 ** 3))} GB\n'
    info += f'ОС: {platform.system()} {platform.release()}\n'
    return info
